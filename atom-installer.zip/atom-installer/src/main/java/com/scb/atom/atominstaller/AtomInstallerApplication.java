package com.scb.atom.atominstaller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtomInstallerApplication {

	public static void main(String[] args) {
		SpringApplication.run(AtomInstallerApplication.class, args);
	}

}
