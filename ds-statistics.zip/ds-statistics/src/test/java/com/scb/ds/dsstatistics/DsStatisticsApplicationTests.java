package com.scb.ds.dsstatistics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DsStatisticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
