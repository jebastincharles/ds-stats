package com.scb.ds.dsstatistics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DsStatisticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(DsStatisticsApplication.class, args);
	}

}
